<?php
/*
Twando.com Free PHP Twitter Application
http://www.twando.com/
*/
?>
<div style="width: 100%; margin-top: 10px; text-align: center;">
<?=mainFuncs::push_response(15)?>
</div
