<?php
/*
Twando.com Free PHP Twitter Application
http://www.twando.com/
*/
?>
<div style="width: 100%; margin-top: 10px; text-align: center;">
<span class="error">You're not logged in or your session has timed out. Please refresh the page and log in again.</span>
</div>

