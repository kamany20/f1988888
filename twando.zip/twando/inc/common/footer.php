
<!-- End of centre main -->
</div>

<div id="footer">
  &copy;<?=date("Y")?> <a href="http://www.twando.com/" target="_blank">Twando.com</a> (Version <?=TWANDO_VERSION?>) | <a rel="nofollow" href="https://twitter.com/twando_com" target="_blank">Twando on Twitter</a>
</div>

<!-- End of container -->
</div>


</body>
</html>
