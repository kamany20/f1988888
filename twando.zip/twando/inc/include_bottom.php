<?php
/*
Twando.com Free PHP Twitter Application
http://www.twando.com/
*/

unset($db);
exit;
?>
